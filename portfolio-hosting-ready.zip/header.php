<!DOCTYPE html>
<html>
<head>
<title>Portfolio Pro</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
<nav>
<a href="?">Home</a> |
<a href="?page=blog">Blog</a> |
<a href="?page=contact">Contact</a> |
<a href="?page=login">Login</a>
</nav>
<hr>
